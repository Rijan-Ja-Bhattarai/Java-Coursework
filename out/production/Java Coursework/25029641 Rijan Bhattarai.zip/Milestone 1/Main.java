public class Main {

    public static void main(String[] args) {
        PersonalPlan freeTier = new PersonalPlan(2, "ATLAS", 223.2322, 1000, 1000);
        ProPlan proTier = new ProPlan(2, "GOTHAM", 1000.0000, 10000, 5000);

        // Test 1
        String resultTest_1_free = freeTier.usePrompt("Lebonbon DA GOAT", 200);
        System.out.println("(Test 1)\nPersonal Plan\n"+ resultTest_1_free);
        System.out.println();
        String resultTest_1_pro = proTier.usePrompt("Lakers Winning the 2026 Championship", 200);
        System.out.println("(Test 1)\nPro Plan\n"+ resultTest_1_pro);

        // Test 2
        System.out.println();
        String resultTest_2_free = freeTier.usePrompt("McLaren Winning F1 2026 Season", 2000);
        System.out.println("(Test 2)\nPersonal Plan\n"+ resultTest_2_free);
        System.out.println();

        String resultTest_2_pro = proTier.usePrompt("McLaren Winning F1 2026 Season", 5000);
        System.out.println("(Test 2)\nPro Plan\n"+ resultTest_2_pro);
        System.out.println();

        // Test 3
        String resultTest_3_free = freeTier.usePrompt("Assignment Finished?", 2);
        String resultTest_31_free = freeTier.usePrompt("Hmm, REDRUM REDUMM RAHHHHHH", 1);
        System.out.println("(Test 3)\nPersonal Plan\n"+ resultTest_3_free);
        System.out.println();
        System.out.println("(Test 3.1)\nPersonal Plan\n"+ resultTest_31_free);
        System.out.println();

        String resultTest_32_free = freeTier.purchasePrompts(5);
        System.out.println("(Test 3.2)\nPersonal Plan\n"+ resultTest_32_free);
        System.out.println();

        // Test 4
        String resultTest_4_pro = proTier.usePrompt("Hi", 2);
        String resultTest_41_pro = proTier.usePrompt("Generate a pic", 2);
        String resultTest_42_pro = proTier.usePrompt("Rijan is so amazing wow", 2);

        System.out.println();
        System.out.println("(Test 4)\nPro Plan\n"+ resultTest_4_pro);
        System.out.println("Pro Plan \n"+ resultTest_41_pro);
        System.out.println("Pro Plan \n"+ resultTest_42_pro);

    }
}