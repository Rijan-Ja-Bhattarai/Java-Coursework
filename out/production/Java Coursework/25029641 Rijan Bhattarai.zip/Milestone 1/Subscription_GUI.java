
/**
 * Write a description of class Subscription_GUI here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Subscription_GUI
{
}